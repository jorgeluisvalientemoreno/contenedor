insert into lectelme values (352961,1,62779,-1,29081,to_date('23/01/2015','dd/mm/yyyy'),1414839,to_date('23/04/2015','dd/mm/yyyy'),1,null, 1001044,3350951,'S',SQ_LECTELME_LEEMCONS.NEXTVAL,62723,1,'F',-1,-1);
insert into lectelme values (352961,1,63084,-1,1414839,to_date('23/04/2015','dd/mm/yyyy'),1436362,to_date('25/05/2015','dd/mm/yyyy'),1,null, 1001044,3350951,'S',SQ_LECTELME_LEEMCONS.NEXTVAL,63028,1,'F',-1,-1);                             
commit;       


